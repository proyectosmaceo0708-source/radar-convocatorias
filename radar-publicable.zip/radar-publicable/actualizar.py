"""Busca convocatorias vigentes con Claude + búsqueda web y actualiza data.json."""
import json, re, datetime, unicodedata, anthropic

HOY = datetime.date.today().isoformat()
MODELO = "claude-sonnet-5-5"
FOCOS = [
 "juntas de acción comunal y organizaciones comunitarias en Colombia",
 "ESAL, fundaciones y ONG colombianas (convocatorias nacionales)",
 "personas naturales en Colombia: artistas, gestores culturales, emprendedores, investigadores, jóvenes",
 "colectivos y grupos de personas sin personería jurídica en Colombia",
 "gobernaciones, alcaldías, institutos departamentales y corporaciones autónomas regionales de Colombia",
 "cooperación internacional, embajadas y organismos multilaterales para organizaciones en Colombia",
 "fundaciones privadas, empresariales y cajas de compensación de Colombia",
 "fondos internacionales de donación abiertos de forma permanente (rolling) elegibles desde Colombia",
]
PROMPT = """Hoy es {hoy}. Busca en la web convocatorias de subvención o financiamiento de proyectos ABIERTAS HOY para: {foco}.
Incluye las que cierran pronto y las de apertura permanente o continua. No incluyas convocatorias cerradas ni inventes datos.
Responde SOLO con un arreglo JSON de objetos con estas claves: nombre, entidad, ambito (Nacional|Regional|Internacional),
tipo (Pública|Privada|Cooperación internacional), apl (lista con valores de: Persona natural, ESAL, JAC, Grupo constituido),
apertura (YYYY-MM-DD o ""), cierre (YYYY-MM-DD o ""), perm (true si es continua), monto, url (página oficial), notas (requisitos clave y de dónde sale la información).
Si no estás seguro de una fecha, déjala vacía."""

def slug(t):
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", t).strip("-")[:70]

def buscar(cli, foco):
    msgs = [{"role": "user", "content": PROMPT.format(hoy=HOY, foco=foco)}]
    for _ in range(4):
        r = cli.messages.create(model=MODELO, max_tokens=6000, messages=msgs,
            tools=[{"type": "web_search_20250305", "name": "web_search", "max_uses": 6}])
        if r.stop_reason != "pause_turn":
            break
        msgs.append({"role": "assistant", "content": r.content})
    txt = "".join(b.text for b in r.content if b.type == "text")
    m = re.search(r"\[.*\]", txt, re.S)
    return json.loads(m.group(0)) if m else []

def vigente(c):
    return c.get("perm") or not c.get("cierre") or c["cierre"] >= HOY

def main():
    cli = anthropic.Anthropic()
    try: previo = json.load(open("data.json", encoding="utf-8"))["items"]
    except Exception: previo = []
    items = {c["id"]: c for c in previo if vigente(c)}
    for foco in FOCOS:
        try: nuevos = buscar(cli, foco)
        except Exception as e:
            print("falló", foco, e); continue
        for c in nuevos:
            if not isinstance(c, dict) or not c.get("nombre") or not str(c.get("url", "")).startswith("http"): continue
            c["id"] = "auto-" + slug(c["nombre"] + " " + c.get("entidad", ""))
            c["apl"] = [a for a in c.get("apl", []) if a in ("Persona natural", "ESAL", "JAC", "Grupo constituido")]
            c.setdefault("estado", "Identificada")
            if vigente(c): items[c["id"]] = c
    json.dump({"actualizado": HOY, "items": list(items.values())}, open("data.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

main()
