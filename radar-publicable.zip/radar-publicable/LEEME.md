# Radar de convocatorias: publicación autónoma

Qué hace: una página web pública (GitHub Pages) que se actualiza sola cada día. Un proceso programado (GitHub Actions) usa Claude con búsqueda web para encontrar convocatorias vigentes o permanentes y guarda el resultado en data.json; la página lo lee al abrirse.

## Pasos (unos 10 minutos)
1. Crea una cuenta en github.com y un repositorio nuevo (público), por ejemplo `radar-convocatorias`.
2. Sube todo el contenido de esta carpeta, incluida la carpeta oculta `.github`.
3. Consigue una clave de API en console.anthropic.com (es de pago por uso).
4. En el repositorio: Settings, Secrets and variables, Actions, New repository secret. Nombre: `ANTHROPIC_API_KEY`; valor: tu clave.
5. En Settings, Pages: Source "Deploy from a branch", rama `main`, carpeta `/ (root)`. La dirección pública aparece ahí (https://TU-USUARIO.github.io/radar-convocatorias/).
6. En la pestaña Actions, abre "Actualizar convocatorias" y pulsa "Run workflow" para la primera actualización. Después corre sola todos los días.

## Notas
- Edita la lista FOCOS en actualizar.py para añadir regiones, temas o tipos de solicitante.
- El estado de gestión y lo que registres a mano se guardan solo en el navegador de cada persona.
- Esta versión no pudo probarse de punta a punta aquí; si la primera ejecución falla, abre el registro en Actions y pásamelo.
- Verifica siempre las bases oficiales antes de postular.
